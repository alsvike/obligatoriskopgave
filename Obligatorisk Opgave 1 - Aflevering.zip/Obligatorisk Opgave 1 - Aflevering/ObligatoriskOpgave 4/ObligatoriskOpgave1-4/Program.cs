﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

Console.WriteLine("TCP Server:");
TcpListener listener = new TcpListener(IPAddress.Any, 7);
listener.Start();
Console.WriteLine("Server started");

Random random = new Random();

while (true)
{
    TcpClient socket = await listener.AcceptTcpClientAsync();
    _ = Task.Run(() => HandleClientAsync(socket));
}

async Task HandleClientAsync(TcpClient socket)
{
    using (socket)
    {
        NetworkStream ns = socket.GetStream();
        StreamReader reader = new StreamReader(ns);
        StreamWriter writer = new StreamWriter(ns);

        string message = null;
        while ((message = await reader.ReadLineAsync()) != null)
        {
            Console.WriteLine("Received: " + message);
            await writer.WriteLineAsync("Echo: " + message);
            await writer.FlushAsync();

            if (message.ToLower() == "random")
            {
                await writer.WriteLineAsync("Please provide the first number");
                await writer.FlushAsync();
                int number1 = Convert.ToInt32(await reader.ReadLineAsync());
                await writer.WriteLineAsync("Please provide the second number");
                await writer.FlushAsync();
                int number2 = Convert.ToInt32(await reader.ReadLineAsync());

                int operation = random.Next(4);
                int result = 0;
                string operationName = "";

                switch (operation)
                {
                    case 0:
                        result = number1 + number2;
                        operationName = "addition";
                        break;
                    case 1:
                        result = number1 - number2;
                        operationName = "subtraction";
                        break;
                    case 2:
                        result = number1 * number2;
                        operationName = "multiplication";
                        break;
                    case 3:
                        result = number1 / number2;
                        operationName = "division";
                        break;
                }

                await writer.WriteLineAsync($"The result of the {operationName} is: " + result);
                await writer.FlushAsync();
                continue;
            }

            if (message.ToLower() == "exit")
            {
                Console.WriteLine("Exiting...");
                break;
            }

            if (message.ToLower() == "add")
            {
                await writer.WriteLineAsync("Please provide the first number");
                await writer.FlushAsync();
                int number1 = Convert.ToInt32(await reader.ReadLineAsync());
                await writer.WriteLineAsync("Please provide the second number");
                await writer.FlushAsync();
                int number2 = Convert.ToInt32(await reader.ReadLineAsync());
                int sum = number1 + number2;
                await writer.WriteLineAsync("The sum of the two numbers is: " + sum);
                await writer.FlushAsync();
                continue;
            }

            if (message.ToLower() == "subtract")
            {
                await writer.WriteLineAsync("Please provide the first number");
                await writer.FlushAsync();
                int number1 = Convert.ToInt32(await reader.ReadLineAsync());
                await writer.WriteLineAsync("Please provide the second number");
                await writer.FlushAsync();
                int number2 = Convert.ToInt32(await reader.ReadLineAsync());
                int sum = number1 - number2;
                await writer.WriteLineAsync("The sum of the two numbers is: " + sum);
                await writer.FlushAsync();
                continue;
            }

            if (message.ToLower() == "multiply")
            {
                await writer.WriteLineAsync("Please provide the first number");
                await writer.FlushAsync();
                int number1 = Convert.ToInt32(await reader.ReadLineAsync());
                await writer.WriteLineAsync("Please provide the second number");
                await writer.FlushAsync();
                int number2 = Convert.ToInt32(await reader.ReadLineAsync());
                int sum = number1 * number2;
                await writer.WriteLineAsync("The sum of the two numbers is: " + sum);
                await writer.FlushAsync();
                continue;
            }

            if (message.ToLower() == "divide")
            {
                await writer.WriteLineAsync("Please provide the first number");
                await writer.FlushAsync();
                int number1 = Convert.ToInt32(await reader.ReadLineAsync());
                await writer.WriteLineAsync("Please provide the second number");
                await writer.FlushAsync();
                int number2 = Convert.ToInt32(await reader.ReadLineAsync());
                int sum = number1 / number2;
                await writer.WriteLineAsync("The sum of the two numbers is: " + sum);
                await writer.FlushAsync();
                continue;
            }
        }
    }
}

listener.Stop();
Console.WriteLine("Server stopped");