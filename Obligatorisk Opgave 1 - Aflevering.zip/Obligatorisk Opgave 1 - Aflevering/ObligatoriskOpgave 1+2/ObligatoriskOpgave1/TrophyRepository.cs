﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObligatoriskOpgave1
{
    public class TrophyRepository
    {
        public List<Trophy> Trophies { get; set; } = new List<Trophy>
        {
            new Trophy(1, "World Cup", 2020),
            new Trophy(2, "Champions League", 2020),
            new Trophy(3, "Premier League", 2020),
            new Trophy(4, "La Liga", 2020),
            new Trophy(5, "Serie A", 2020)
        };

        public List<Trophy> GetTrophies(int? year, string competition)
        {
            if (year == null && competition == null)
            {
                return Trophies;
            }
            if (year != null && competition == null)
            {
                return Trophies.FindAll(t => t.Year == year);
            }
            if (year == null && competition != null)
            {
                return Trophies.FindAll(t => t.Competition == competition);
            }
            return Trophies.FindAll(t => t.Year == year && t.Competition == competition);
        }
        public Trophy GetTrophyById(int id)
        {
            return Trophies.Find(t => t.Id == id);
        }

        public void AddTrophy(int id, string competition, int year)
        {
            var trophy = new Trophy(id, competition, year);
            Trophies.Add(trophy);
        }

        public void RemoveTrophy(int id)
        {
            var trophy = GetTrophyById(id);
            if (trophy == null)
            {
                throw new ArgumentException("Trophy does not exist");
            }
            Trophies.Remove(trophy);
        }

        public Trophy UpdateTrophy(int id, string competition, int year)
        {
            var trophy = GetTrophyById(id);
            if (trophy == null)
            {
                throw new ArgumentException("Trophy does not exist");
            }
            trophy.Competition = competition;
            trophy.Year = year;
            return trophy;
        }
    }
}
