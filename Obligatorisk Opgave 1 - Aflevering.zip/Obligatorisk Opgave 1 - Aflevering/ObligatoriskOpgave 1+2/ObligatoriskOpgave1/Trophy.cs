﻿namespace ObligatoriskOpgave1
{
    public class Trophy
    {
        public int Id { get; set; }
        public string Competition { get; set; }
        public int Year { get; set; }

        public Trophy() { }

        public Trophy(int id, string competition, int year)
        {
            Id = id;
            Competition = competition;
            Year = year;
        }

        public void ValidateId()
        {
            if (Id < 1)
            {
                throw new ArgumentException("ID must be greater than 0");
            }
        }
        public void ValidateCompetition()
        {
            if (string.IsNullOrEmpty(Competition))
            {
                throw new ArgumentException("Competition must not be null or empty");
            }
            if (Competition.Length < 3)
            {
                throw new ArgumentException("Competition must be at least 3 characters long");
            }
        }
        public void ValidateYear()
        {
            if (Year < 1970 || Year > 2024)
            {
                throw new ArgumentException("Year must be between 1970 and 2024");
            }
        }
        public override string ToString()
        {
            return $"Trophy ID: {Id}, Competition: {Competition}, Year: {Year}";
        }
    }
}
