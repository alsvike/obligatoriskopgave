﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ObligatoriskOpgave1;
using System;

namespace ObligatoriskOpgave1.Tests
{
    [TestClass()]
    public class TrophyTests
    {
        [TestMethod()]
        public void TrophyTest()
        {
            var trophy = new Trophy();
            Assert.AreEqual(0, trophy.Id);
            Assert.AreEqual(null, trophy.Competition);
            Assert.AreEqual(0, trophy.Year);
        }

        [TestMethod()]
        public void TrophyTest1()
        {
            var trophy = new Trophy(1, "World Cup", 2020);
            Assert.AreEqual(1, trophy.Id);
            Assert.AreEqual("World Cup", trophy.Competition);
            Assert.AreEqual(2020, trophy.Year);
        }

        [TestMethod()]
        public void ValidateIdTest_ValidId()
        {
            var trophy = new Trophy(1, "World Cup", 2020);
            trophy.ValidateId();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateIdTest_InvalidId()
        {
            var trophy = new Trophy(0, "World Cup", 2020);
            trophy.ValidateId();
        }

        [TestMethod()]
        public void ValidateCompetitionTest_Valid()
        {
            var trophy = new Trophy(1, "Champions League", 2020);
            trophy.ValidateCompetition();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateCompetitionTest_EmptyCompetition()
        {
            var trophy = new Trophy(1, "", 2020);
            trophy.ValidateCompetition();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateCompetitionTest_ShortCompetition()
        {
            var trophy = new Trophy(1, "WC", 2020);
            trophy.ValidateCompetition();
        }

        [TestMethod()]
        public void ValidateYearTest_ValidYear()
        {
            var trophy = new Trophy(1, "World Cup", 2020);
            trophy.ValidateYear();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateYearTest_InvalidYear_Low()
        {
            var trophy = new Trophy(1, "World Cup", 1969);
            trophy.ValidateYear();
        }

        [TestMethod()]
        [ExpectedException(typeof(ArgumentException))]
        public void ValidateYearTest_InvalidYear_High()
        {
            var trophy = new Trophy(1, "World Cup", 2025);
            trophy.ValidateYear();
        }

        [TestMethod()]
        public void ToStringTest()
        {
            var trophy = new Trophy(1, "World Cup", 2020);
            var expectedString = "Trophy ID: 1, Competition: World Cup, Year: 2020";
            Assert.AreEqual(expectedString, trophy.ToString());
        }
    }
}
